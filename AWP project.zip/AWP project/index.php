<?php
$page_title = "Home";
require_once 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero text-center">
    <div class="container">
        <h1>Freshly Baked Goodness</h1>
        <p class="lead mb-4">Welcome to Sweet Delights Bakery, where every bite is a celebration of flavor and tradition.</p>
        <a href="products.php" class="btn btn-primary btn-lg">Explore Our Products</a>
    </div>
</section>

<!-- Featured Products Section -->
<section class="mb-5">
    <div class="container">
        <h2 class="text-center mb-4">Featured Products</h2>
        <div class="row">
            <?php
            $sql = "SELECT p.*, c.name as category_name 
                    FROM products p 
                    JOIN categories c ON p.category_id = c.id 
                    WHERE p.featured = 1 
                    LIMIT 4";
            try {
                global $pdo;
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if ($products && count($products) > 0) {
                    foreach ($products as $product) {
            ?>
            <div class="col-md-3 col-sm-6">
                <div class="card product-card h-100">
                    <div class="product-img-container d-flex align-items-center justify-content-center">
                        <?php if ($product['image']): ?>
                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="card-img-top">
                        <?php else: ?>
                        <i class="fas fa-cookie"></i>
                        <?php endif; ?>
                        <?php if ($product['featured']): ?>
                        <span class="badge bg-primary product-badge">Featured</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $product['name']; ?></h5>
                        <p class="card-text text-muted small"><?php echo $product['category_name']; ?></p>
                        <p class="product-price mb-2"><?php echo formatPrice($product['price']); ?></p>
                        <form action="cart.php" method="post">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <div class="d-grid gap-2">
                                <a href="product-detail.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                                <button type="submit" class="btn btn-primary btn-sm add-to-cart-btn">
                                    <i class="fas fa-shopping-cart me-1"></i> Add to Cart
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
                    }
                } else {
                    echo '<div class="col-12"><p class="text-center">No featured products available.</p></div>';
                }
            } catch (PDOException $e) {
                echo '<div class="col-12"><p class="text-center text-danger">Error loading products: ' . $e->getMessage() . '</p></div>';
            }
            ?>
        </div>
        <div class="text-center mt-4">
            <a href="products.php" class="btn btn-outline-primary">View All Products</a>
        </div>
    </div>
</section>


<!-- Categories Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4">Our Categories</h2>
        <div class="row">
            <?php
            global $pdo;
            $categories = getCategories($pdo);
            
            foreach ($categories as $category) {
            ?>
            <div class="col-md-4 col-sm-6">
                <!-- Category Card -->
                <div class="card">
                    <div class="card-body">
                        <!-- Category Name -->
                        <h5 class="card-title"><?php echo htmlspecialchars($category['name']); ?></h5>
                        <!-- Category Description -->
                        <p class="card-text"><?php echo htmlspecialchars($category['description']); ?></p>
                        <!-- Category Link (Optional) -->
                        <a href="category.php?id=<?php echo $category['id']; ?>" class="btn btn-primary">Explore</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>



<!-- About Us Summary Section -->
<section class="container my-5">
    <div class="row align-items-center">
        <div class="col-lg-6">
            <h2>About Sweet Delights</h2>
            <p>At Sweet Delights Bakery, we're passionate about creating mouthwatering baked goods that bring joy to our customers. Our journey began in 2010 with a simple mission: to share our love for authentic, high-quality baking.</p>
            <p>We use only the finest ingredients, traditional methods, and a dash of innovation to create our delicious products. Every item is baked fresh daily in our kitchen, ensuring you get the best quality and taste.</p>
            <a href="about.php" class="btn btn-primary">Learn More About Us</a>
        </div>
        <div class="col-lg-6 mt-4 mt-lg-0">
            <div class="ratio ratio-16x9">
                <div class="bg-secondary-light d-flex align-items-center justify-content-center">
                    <i class="fas fa-hands-helping fa-5x text-primary opacity-25"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5">What Our Customers Say</h2>
        <div class="row">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="card-text">"The cakes from Sweet Delights are simply amazing! I ordered a birthday cake for my daughter and it was not only beautiful but delicious too. Everyone at the party loved it!"</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <span>SM</span>
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0">Sarah Miller</h6>
                                <small class="text-muted">Regular Customer</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="card-text">"I'm gluten intolerant and finding good baked goods can be a challenge. Sweet Delights' gluten-free bread is the best I've ever had. It doesn't even taste gluten-free! Thank you for being so inclusive."</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <span>JT</span>
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0">James Thompson</h6>
                                <small class="text-muted">Loyal Customer</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                        <p class="card-text">"I ordered a selection of pastries for a corporate event, and everyone was impressed. The delivery was on time, everything was beautifully presented, and most importantly, everything tasted fantastic. Will definitely order again!"</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <span>EJ</span>
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0">Emma Johnson</h6>
                                <small class="text-muted">Event Coordinator</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Newsletter Section -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2>Subscribe to Our Newsletter</h2>
                <p class="mb-4">Stay updated with our latest creations, seasonal specials, and exclusive offers.</p>
                <form class="row g-3 justify-content-center">
                    <div class="col-md-8">
                        <input type="email" class="form-control form-control-lg" placeholder="Enter your email address" required>
                    </div>
                    <div class="col-md-auto">
                        <button type="submit" class="btn btn-light btn-lg">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
