<?php
$page_title = "About Us";
require_once 'includes/header.php';
?>

<!-- About Hero Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="mb-4">About Sweet Delights</h1>
                <p class="lead">We're more than a bakery – we're a passionate team dedicated to creating delicious memories.</p>
                <p>Founded in 2010, Sweet Delights Bakery has been serving the community with fresh, handcrafted baked goods made from the finest ingredients. Our mission is simple: to create delicious treats that bring joy to our customers and make every occasion special.</p>
            </div>
            <div class="col-lg-6">
                <div class="ratio ratio-16x9 rounded shadow">
                    <div class="bg-secondary-light d-flex align-items-center justify-content-center">
                        <i class="fas fa-store fa-5x text-primary opacity-25"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Story Section -->
<section class="container my-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h2 class="text-center mb-4">Our Story</h2>
            <p>Sweet Delights Bakery was born from a passion for creating exceptional baked goods that not only taste amazing but also bring people together. Our journey began when founder Emma Thompson, a trained pastry chef with experience in renowned establishments across the country, decided to bring her expertise and love for baking to our community.</p>
            
            <p>What started as a small operation with just a few signature items has grown into a beloved local bakery offering a wide range of breads, pastries, cakes, and more. Despite our growth, we've never compromised on our commitment to quality and authenticity.</p>
            
            <p>Each morning, our bakers arrive before dawn to mix, knead, and shape our products by hand. We use traditional methods passed down through generations, combined with innovative techniques to create our unique offerings. Every ingredient is carefully selected – from locally sourced butter and eggs to the finest imported chocolates and spices.</p>
            
            <p>Over the years, we've become more than just a place to buy baked goods. Sweet Delights has evolved into a community hub where people gather to celebrate special moments, catch up with friends over coffee and pastries, or simply start their day with a freshly baked treat.</p>
            
            <p>Today, we continue to honor our founding principles while constantly evolving to meet our customers' needs. Whether you're looking for a showstopping celebration cake, a rustic loaf of sourdough, or a simple cookie to brighten your day, we're here to serve you with the same passion and dedication that has defined Sweet Delights since day one.</p>
        </div>
    </div>
</section>

<!-- Our Values Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5">Our Values</h2>
        <div class="row text-center">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="bg-white p-4 h-100 shadow-sm rounded">
                    <i class="fas fa-leaf fa-3x text-primary mb-3"></i>
                    <h3>Quality Ingredients</h3>
                    <p>We use only the finest, freshest ingredients in all our products. Whenever possible, we source locally and seasonally to ensure optimal flavor and to support our community.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="bg-white p-4 h-100 shadow-sm rounded">
                    <i class="fas fa-hands fa-3x text-primary mb-3"></i>
                    <h3>Handcrafted with Love</h3>
                    <p>Every item is made by hand with attention to detail and a commitment to excellence. We take pride in the artisanal quality of our products and the skill of our bakers.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-white p-4 h-100 shadow-sm rounded">
                    <i class="fas fa-heart fa-3x text-primary mb-3"></i>
                    <h3>Community Focus</h3>
                    <p>We believe in giving back to the community that supports us. Through charitable initiatives, local partnerships, and sustainable practices, we strive to make a positive impact.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Meet Our Team Section -->
<section class="container my-5">
    <h2 class="text-center mb-5">Meet Our Team</h2>
    <div class="row">
        <div class="col-lg-3 col-md-6">
            <div class="baker-card">
                <div class="bg-secondary-light rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto baker-img">
                    <i class="fas fa-user fa-3x text-primary opacity-25"></i>
                </div>
                <h4>Emma Thompson</h4>
                <p class="text-muted">Founder & Head Baker</p>
                <p>With over 15 years of experience in top bakeries, Emma brings her passion and expertise to every recipe at Sweet Delights.</p>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="baker-card">
                <div class="bg-secondary-light rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto baker-img">
                    <i class="fas fa-user fa-3x text-primary opacity-25"></i>
                </div>
                <h4>David Chen</h4>
                <p class="text-muted">Pastry Chef</p>
                <p>David specializes in creating our delicate pastries and is known for his innovative flavor combinations and impeccable technique.</p>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="baker-card">
                <div class="bg-secondary-light rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto baker-img">
                    <i class="fas fa-user fa-3x text-primary opacity-25"></i>
                </div>
                <h4>Sophia Rodriguez</h4>
                <p class="text-muted">Bread Specialist</p>
                <p>Sophia's sourdough has become legendary in our community. She brings traditional bread-making techniques to everything she creates.</p>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="baker-card">
                <div class="bg-secondary-light rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto baker-img">
                    <i class="fas fa-user fa-3x text-primary opacity-25"></i>
                </div>
                <h4>Michael Johnson</h4>
                <p class="text-muted">Cake Designer</p>
                <p>Michael's artistic background makes him the perfect person to create our beautiful custom cakes for all special occasions.</p>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5">What Our Customers Say</h2>
        <div class="row">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="card-text">"I've been coming to Sweet Delights for years, and the quality has never wavered. Their croissants are as good as any I've had in Paris, and the staff always make me feel like family."</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <span>RL</span>
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0">Robert Lewis</h6>
                                <small class="text-muted">Loyal Customer</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="card-text">"Sweet Delights made my wedding cake, and it was absolutely stunning. Not only did it look beautiful, but it was delicious too! Everyone was asking for the recipe."</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <span>AW</span>
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0">Amanda Wilson</h6>
                                <small class="text-muted">Happy Bride</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                        <p class="card-text">"As a local café owner, I exclusively source my baked goods from Sweet Delights. Their consistency, quality, and professionalism are unmatched. My customers rave about their pastries every day."</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <span>TN</span>
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0">Thomas Nguyen</h6>
                                <small class="text-muted">Business Partner</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="container my-5 text-center">
    <div class="py-5 px-4 bg-primary text-white rounded shadow">
        <h2 class="mb-3">Come Visit Us!</h2>
        <p class="lead mb-4">Experience the aroma of freshly baked goods and the warm, welcoming atmosphere of our bakery.</p>
        <div class="row justify-content-center">
            <div class="col-md-4 mb-3 mb-md-0">
                <h5><i class="fas fa-map-marker-alt me-2"></i> Location</h5>
                <p class="mb-0">123 Bakery Street<br>City, Country</p>
            </div>
            <div class="col-md-4 mb-3 mb-md-0">
                <h5><i class="fas fa-clock me-2"></i> Hours</h5>
                <p class="mb-0">Monday to Friday: 7:00 AM - 7:00 PM<br>Saturday & Sunday: 8:00 AM - 5:00 PM</p>
            </div>
            <div class="col-md-4">
                <h5><i class="fas fa-phone me-2"></i> Contact</h5>
                <p class="mb-0">(123) 456-7890<br>info@sweetdelights.com</p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
