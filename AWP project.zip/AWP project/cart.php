<?php
$page_title = "Shopping Cart";
require_once 'includes/header.php';

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    if ($action === 'add') {
        $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($product_id > 0) {
            addToCart($product_id, $quantity);
            $_SESSION['message'] = "Product added to cart.";
            $_SESSION['message_type'] = "success";
        }
    } elseif ($action === 'update') {
        $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($product_id > 0) {
            updateCartItem($product_id, $quantity);
            $_SESSION['message'] = "Cart updated.";
            $_SESSION['message_type'] = "success";
        }
    } elseif ($action === 'remove') {
        $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        
        if ($product_id > 0) {
            removeCartItem($product_id);
            $_SESSION['message'] = "Product removed from cart.";
            $_SESSION['message_type'] = "success";
        }
    } elseif ($action === 'clear') {
        unset($_SESSION['cart']);
        $_SESSION['message'] = "Cart cleared.";
        $_SESSION['message_type'] = "success";
    } elseif ($action === 'checkout') {
        // In a real application, this would redirect to a checkout process
        // For this demo, we'll just show a success message and clear the cart
        
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            unset($_SESSION['cart']);
            $_SESSION['message'] = "Thank you for your order! This is a demo, so no actual purchase was made.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Your cart is empty.";
            $_SESSION['message_type'] = "warning";
        }
    }
    
    // Redirect to avoid form resubmission
    header("Location: cart.php");
    exit;
}

// Get cart items
$cart = getCartItems($conn);
?>

<!-- Cart Page -->
<section class="container my-5">
    <h1 class="mb-4">Your Shopping Cart</h1>
    
    <?php if (count($cart['items']) > 0): ?>
    <div class="row">
        <div class="col-lg-8">
            <!-- Cart Items -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Cart Items</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($cart['items'] as $item): ?>
                    <div class="cart-item">
                        <div class="row align-items-center">
                            <div class="col-2 col-md-1">
                                <div class="cart-item-image d-flex align-items-center justify-content-center">
                                    <?php if ($item['image']): ?>
                                    <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="img-fluid">
                                    <?php else: ?>
                                    <i class="fas fa-cookie text-primary"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-5 col-md-6">
                                <h5><?php echo $item['name']; ?></h5>
                                <p class="text-primary mb-0"><?php echo formatPrice($item['price']); ?> each</p>
                            </div>
                            <div class="col-3 col-md-3">
                                <form action="cart.php" method="post">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <div class="input-group">
                                        <input type="number" name="quantity" class="form-control cart-quantity-input" value="<?php echo $item['quantity']; ?>" min="1" max="99">
                                        <button type="submit" class="btn btn-outline-secondary">
                                            <i class="fas fa-sync-alt"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-2 col-md-2 text-end">
                                <p class="fw-bold mb-2"><?php echo formatPrice($item['subtotal']); ?></p>
                                <form action="cart.php" method="post">
                                    <input type="hidden" name="action" value="remove">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                    <form action="cart.php" method="post">
                        <input type="hidden" name="action" value="clear">
                        <button type="submit" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-trash-alt me-1"></i> Clear Cart
                        </button>
                    </form>
                    <a href="products.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-shopping-bag me-1"></i> Continue Shopping
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <!-- Order Summary -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Order Summary</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal</span>
                        <span><?php echo formatPrice($cart['total']); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Shipping</span>
                        <span>Free</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tax</span>
                        <span><?php echo formatPrice($cart['total'] * 0.1); ?></span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-4">
                        <span class="fw-bold">Total</span>
                        <span class="fw-bold text-primary"><?php echo formatPrice($cart['total'] * 1.1); ?></span>
                    </div>
                    <form action="cart.php" method="post">
                        <input type="hidden" name="action" value="checkout">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-credit-card me-2"></i> Proceed to Checkout
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Promo Code -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Promo Code</h5>
                </div>
                <div class="card-body">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Enter promo code">
                        <button class="btn btn-outline-primary" type="button">Apply</button>
                    </div>
                    <small class="text-muted">Enter a valid promo code to get a discount</small>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
        <h3>Your cart is empty</h3>
        <p>Looks like you haven't added any products to your cart yet.</p>
        <a href="products.php" class="btn btn-primary mt-3">
            <i class="fas fa-shopping-bag me-2"></i> Browse Products
        </a>
    </div>
    <?php endif; ?>
</section>

<!-- You May Also Like Section -->
<section class="container mb-5">
    <h3 class="mb-4">You May Also Like</h3>
    <div class="row">
        <?php
        $sql = "SELECT p.*, c.name as category_name 
                FROM products p 
                JOIN categories c ON p.category_id = c.id 
                ORDER BY RAND() 
                LIMIT 4";
        $result = $conn->query($sql);
        
        if ($result && $result->rowCount() > 0) {
            while ($product = $result->fetch(PDO::FETCH_ASSOC)) {
        ?>
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card product-card h-100">
                <div class="product-img-container d-flex align-items-center justify-content-center">
                    <?php if ($product['image']): ?>
                    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="card-img-top">
                    <?php else: ?>
                    <i class="fas fa-cookie"></i>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $product['name']; ?></h5>
                    <p class="product-price mb-2"><?php echo formatPrice($product['price']); ?></p>
                    <div class="d-grid gap-2">
                        <a href="product-detail.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                        <form action="cart.php" method="post">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" class="btn btn-primary btn-sm w-100 add-to-cart-btn">
                                <i class="fas fa-shopping-cart me-1"></i> Add to Cart
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
            }
        }
        ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
