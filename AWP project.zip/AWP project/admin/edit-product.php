<?php
// Include necessary files
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as admin
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit;
}

// Get all categories for dropdown
$categories = getCategories($conn);

// Initialize variables
$name = '';
$description = '';
$price = '';
$category_id = '';
$featured = 0;
$allergens = '';
$ingredients = '';
$image = '';

// Initialize error variables
$name_err = '';
$description_err = '';
$price_err = '';
$category_id_err = '';
$image_err = '';
$product_err = '';

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message'] = "No product selected for editing.";
    $_SESSION['message_type'] = "warning";
    header("Location: products.php");
    exit;
}

$product_id = (int)$_GET['id'];

// Get product data
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['message'] = "Product not found.";
    $_SESSION['message_type'] = "danger";
    header("Location: products.php");
    exit;
}

$product = $result->fetch_assoc();
$stmt->close();

// Fill in form with existing data
$name = $product['name'];
$description = $product['description'];
$price = $product['price'];
$category_id = $product['category_id'];
$featured = $product['featured'];
$allergens = $product['allergens'];
$ingredients = $product['ingredients'];
$image = $product['image'];

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate name
    if (empty(trim($_POST['name']))) {
        $name_err = 'Please enter product name';
    } else {
        $name = trim($_POST['name']);
    }
    
    // Validate description
    if (empty(trim($_POST['description']))) {
        $description_err = 'Please enter product description';
    } else {
        $description = trim($_POST['description']);
    }
    
    // Validate price
    if (empty(trim($_POST['price']))) {
        $price_err = 'Please enter product price';
    } else {
        $price = trim($_POST['price']);
        if (!is_numeric($price) || $price <= 0) {
            $price_err = 'Please enter a valid price (greater than 0)';
        }
    }
    
    // Validate category
    if (empty($_POST['category_id'])) {
        $category_id_err = 'Please select a category';
    } else {
        $category_id = (int)$_POST['category_id'];
    }
    
    // Get featured status
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    // Get allergens and ingredients
    $allergens = trim($_POST['allergens'] ?? '');
    $ingredients = trim($_POST['ingredients'] ?? '');
    
    // Handle image URL
    $image = trim($_POST['image'] ?? '');
    
    // If no errors, update product in database
    if (empty($name_err) && empty($description_err) && empty($price_err) && empty($category_id_err)) {
        $sql = "UPDATE products 
                SET name = ?, description = ?, price = ?, category_id = ?, 
                    featured = ?, allergens = ?, ingredients = ?, image = ? 
                WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdissssi", $name, $description, $price, $category_id, 
                          $featured, $allergens, $ingredients, $image, $product_id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Product updated successfully.";
            $_SESSION['message_type'] = "success";
            
            header("Location: products.php");
            exit;
        } else {
            $_SESSION['message'] = "Error updating product: " . $conn->error;
            $_SESSION['message_type'] = "danger";
        }
        
        $stmt->close();
    }
}

$page_title = "Edit Product";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sweet Delights Bakery</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Raleway:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <!-- Admin Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="../assets/bakery-logo.svg" alt="Sweet Delights Bakery" height="40">
                Admin Panel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="adminNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php" target="_blank">View Website</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <span class="navbar-text me-3">
                        Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>
                    </span>
                    <a href="logout.php" class="btn btn-outline-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-dark admin-sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="products.php">
                                <i class="fas fa-cookie-bite"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="add-product.php">
                                <i class="fas fa-plus"></i> Add Product
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../index.php" target="_blank">
                                <i class="fas fa-external-link-alt"></i> View Website
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Product</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back to Products
                        </a>
                    </div>
                </div>
                
                <?php
                // Display session messages if any
                if (isset($_SESSION['message'])) {
                    echo showAlert($_SESSION['message'], $_SESSION['message_type'] ?? 'info');
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                }
                ?>
                
                <!-- Edit Product Form -->
                <div class="card mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Product Information</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $product_id; ?>" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php echo !empty($name_err) ? 'is-invalid' : ''; ?>" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                                        <?php if (!empty($name_err)): ?>
                                        <div class="invalid-feedback"><?php echo $name_err; ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="price" class="form-label">Price ($) <span class="text-danger">*</span></label>
                                        <input type="number" step="0.01" min="0.01" class="form-control <?php echo !empty($price_err) ? 'is-invalid' : ''; ?>" id="price" name="price" value="<?php echo htmlspecialchars($price); ?>" required>
                                        <?php if (!empty($price_err)): ?>
                                        <div class="invalid-feedback"><?php echo $price_err; ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
                                        <select class="form-select <?php echo !empty($category_id_err) ? 'is-invalid' : ''; ?>" id="category_id" name="category_id" required>
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>" <?php echo $category_id == $category['id'] ? 'selected' : ''; ?>>
                                                <?php echo $category['name']; ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <?php if (!empty($category_id_err)): ?>
                                        <div class="invalid-feedback"><?php echo $category_id_err; ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="featured" name="featured" value="1" <?php echo $featured ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="featured">
                                                Featured Product
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="image" class="form-label">Image URL</label>
                                        <input type="text" class="form-control" id="image" name="image" value="<?php echo htmlspecialchars($image); ?>">
                                        <div class="form-text">Enter a URL for the product image or leave blank for default icon.</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="allergens" class="form-label">Allergens</label>
                                        <input type="text" class="form-control" id="allergens" name="allergens" value="<?php echo htmlspecialchars($allergens); ?>">
                                        <div class="form-text">E.g., "Contains: Wheat, Eggs, Milk" or leave blank if not applicable.</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="ingredients" class="form-label">Ingredients</label>
                                        <input type="text" class="form-control" id="ingredients" name="ingredients" value="<?php echo htmlspecialchars($ingredients); ?>">
                                        <div class="form-text">Main ingredients or leave blank if not applicable.</div>
                                    </div>
                                    
                                    <!-- Image Preview -->
                                    <div class="mt-3 text-center">
                                        <div class="mb-3">
                                            <?php if (!empty($image)): ?>
                                            <img id="image-preview" src="<?php echo htmlspecialchars($image); ?>" alt="Product Image Preview" style="max-width: 100%; max-height: 200px;">
                                            <?php else: ?>
                                            <img id="image-preview" src="#" alt="Product Image Preview" style="max-width: 100%; max-height: 200px; display: none;">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="description" class="form-label">Description <span class="text-danger">*</span></label>
                                        <textarea class="form-control <?php echo !empty($description_err) ? 'is-invalid' : ''; ?>" id="description" name="description" rows="4" required><?php echo htmlspecialchars($description); ?></textarea>
                                        <?php if (!empty($description_err)): ?>
                                        <div class="invalid-feedback"><?php echo $description_err; ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Update Product
                                </button>
                                <a href="products.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <footer class="pt-3 mt-4 text-muted border-top">
                    &copy; <?php echo date('Y'); ?> Sweet Delights Bakery
                </footer>
            </main>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Preview Image Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const imageInput = document.getElementById('image');
            const imagePreview = document.getElementById('image-preview');
            
            // Function to update image preview
            function updateImagePreview() {
                const imageUrl = imageInput.value.trim();
                
                if (imageUrl) {
                    imagePreview.src = imageUrl;
                    imagePreview.style.display = 'block';
                } else {
                    imagePreview.style.display = 'none';
                }
            }
            
            // Update on input change
            imageInput.addEventListener('input', updateImagePreview);
        });
    </script>
</body>
</html>
