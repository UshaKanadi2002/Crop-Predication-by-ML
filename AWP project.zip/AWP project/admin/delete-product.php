<?php
// Include necessary files
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as admin
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit;
}

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message'] = "No product selected for deletion.";
    $_SESSION['message_type'] = "warning";
    header("Location: products.php");
    exit;
}

$product_id = (int)$_GET['id'];

// Check if product exists
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['message'] = "Product not found.";
    $_SESSION['message_type'] = "danger";
    header("Location: products.php");
    exit;
}

$stmt->close();

// Process deletion if confirmed
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    // Delete the product
    $sql = "DELETE FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Product deleted successfully.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting product: " . $conn->error;
        $_SESSION['message_type'] = "danger";
    }
    
    $stmt->close();
    
    // Redirect back to products page
    header("Location: products.php");
    exit;
}

// Get product details for confirmation
$sql = "SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();

$page_title = "Delete Product";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sweet Delights Bakery</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Raleway:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <!-- Admin Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="../assets/bakery-logo.svg" alt="Sweet Delights Bakery" height="40">
                Admin Panel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="adminNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php" target="_blank">View Website</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <span class="navbar-text me-3">
                        Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>
                    </span>
                    <a href="logout.php" class="btn btn-outline-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-dark admin-sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="products.php">
                                <i class="fas fa-cookie-bite"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="add-product.php">
                                <i class="fas fa-plus"></i> Add Product
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../index.php" target="_blank">
                                <i class="fas fa-external-link-alt"></i> View Website
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Delete Product</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back to Products
                        </a>
                    </div>
                </div>
                
                <?php
                // Display session messages if any
                if (isset($_SESSION['message'])) {
                    echo showAlert($_SESSION['message'], $_SESSION['message_type'] ?? 'info');
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                }
                ?>
                
                <!-- Confirmation Card -->
                <div class="card mb-4">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">Confirm Deletion</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i> 
                            Are you sure you want to delete this product? This action cannot be undone.
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-md-4 text-center mb-4 mb-md-0">
                                <div style="width: 150px; height: 150px;" class="bg-light rounded d-flex align-items-center justify-content-center mx-auto">
                                    <?php if ($product['image']): ?>
                                    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="img-fluid" style="max-height: 100%;">
                                    <?php else: ?>
                                    <i class="fas fa-cookie fa-5x text-primary opacity-50"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p><strong>Category:</strong> <?php echo htmlspecialchars($product['category_name']); ?></p>
                                <p><strong>Price:</strong> <?php echo formatPrice($product['price']); ?></p>
                                <p><strong>Featured:</strong> <?php echo $product['featured'] ? 'Yes' : 'No'; ?></p>
                                <p class="mb-0"><strong>Description:</strong></p>
                                <p><?php echo htmlspecialchars(substr($product['description'], 0, 150)) . (strlen($product['description']) > 150 ? '...' : ''); ?></p>
                            </div>
                        </div>
                        
                        <div class="mt-4 text-center">
                            <a href="delete-product.php?id=<?php echo $product_id; ?>&confirm=yes" class="btn btn-danger">
                                <i class="fas fa-trash me-1"></i> Yes, Delete Product
                            </a>
                            <a href="products.php" class="btn btn-secondary ms-2">
                                <i class="fas fa-times me-1"></i> Cancel
                            </a>
                        </div>
                    </div>
                </div>
                
                <footer class="pt-3 mt-4 text-muted border-top">
                    &copy; <?php echo date('Y'); ?> Sweet Delights Bakery
                </footer>
            </main>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
