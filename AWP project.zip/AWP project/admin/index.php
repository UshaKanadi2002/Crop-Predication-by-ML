<?php
// Include necessary files
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as admin
if (!isAdmin()) {
    $_SESSION['message'] = 'You must be logged in as an administrator to access this area.';
    $_SESSION['message_type'] = 'warning';
    header("Location: login.php");
    exit;
}

// Get dashboard statistics
// Product count
try {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM products");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $product_count = $result['total'] ?? 0;
} catch (PDOException $e) {
    $product_count = 0;
    // Log error
    error_log("Database error: " . $e->getMessage());
}

// Category count
try {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM categories");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $category_count = $result['total'] ?? 0;
} catch (PDOException $e) {
    $category_count = 0;
    // Log error
    error_log("Database error: " . $e->getMessage());
}

// Featured product count
try {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM products WHERE featured = 1");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $featured_count = $result['total'] ?? 0;
} catch (PDOException $e) {
    $featured_count = 0;
    // Log error
    error_log("Database error: " . $e->getMessage());
}

// Recent products
$recent_products = [];
try {
    global $pdo;
    $stmt = $pdo->prepare("SELECT p.*, c.name as category_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            ORDER BY p.id DESC 
            LIMIT 5");
    $stmt->execute();
    $recent_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Log error
    error_log("Database error: " . $e->getMessage());
}

// Recent contact messages
$recent_messages = [];
try {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 5");
    $stmt->execute();
    $recent_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Log error
    error_log("Database error: " . $e->getMessage());
}

$page_title = "Admin Dashboard";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sweet Delights Bakery</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Raleway:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <!-- Admin Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="../assets/bakery-logo.svg" alt="Sweet Delights Bakery" height="40">
                Admin Panel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="adminNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php" target="_blank">View Website</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <span class="navbar-text me-3">
                        Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                    </span>
                    <a href="logout.php" class="btn btn-outline-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-dark admin-sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">
                                <i class="fas fa-cookie-bite"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="add-product.php">
                                <i class="fas fa-plus"></i> Add Product
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../index.php" target="_blank">
                                <i class="fas fa-external-link-alt"></i> View Website
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add-product.php" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i> Add New Product
                        </a>
                    </div>
                </div>
                
                <?php
                // Display session messages if any
                if (isset($_SESSION['message'])) {
                    echo showAlert($_SESSION['message'], $_SESSION['message_type'] ?? 'info');
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                }
                ?>
                
                <!-- Stats Cards -->
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card border-primary h-100">
                            <div class="card-body text-center">
                                <h3 class="display-4 text-primary"><?php echo $product_count; ?></h3>
                                <p class="card-text">Total Products</p>
                                <a href="products.php" class="btn btn-sm btn-outline-primary">View All Products</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card border-success h-100">
                            <div class="card-body text-center">
                                <h3 class="display-4 text-success"><?php echo $category_count; ?></h3>
                                <p class="card-text">Product Categories</p>
                                <a href="products.php" class="btn btn-sm btn-outline-success">Manage Categories</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card border-warning h-100">
                            <div class="card-body text-center">
                                <h3 class="display-4 text-warning"><?php echo $featured_count; ?></h3>
                                <p class="card-text">Featured Products</p>
                                <a href="products.php" class="btn btn-sm btn-outline-warning">Manage Featured</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Products -->
                <div class="card mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Recent Products</h5>
                        <a href="products.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Featured</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_products as $product): ?>
                                    <tr>
                                        <td><?php echo $product['id']; ?></td>
                                        <td><?php echo $product['name']; ?></td>
                                        <td><?php echo $product['category_name']; ?></td>
                                        <td><?php echo formatPrice($product['price']); ?></td>
                                        <td>
                                            <?php if ($product['featured']): ?>
                                            <span class="badge bg-success">Yes</span>
                                            <?php else: ?>
                                            <span class="badge bg-secondary">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="edit-product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-primary me-1">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="delete-product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this product?');">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <?php if (count($recent_products) === 0): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">No products found.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Contact Messages -->
                <div class="card mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Recent Contact Messages</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($recent_messages) > 0): ?>
                            <?php foreach ($recent_messages as $message): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="mb-0"><?php echo htmlspecialchars($message['name']); ?> <small class="text-muted">&lt;<?php echo htmlspecialchars($message['email']); ?>&gt;</small></h6>
                                    <small class="text-muted"><?php echo date('M j, Y, g:i a', strtotime($message['created_at'])); ?></small>
                                </div>
                                <p class="text-muted mb-1"><strong>Subject:</strong> <?php echo htmlspecialchars($message['subject'] ?: 'No subject'); ?></p>
                                <p class="mb-0"><?php echo htmlspecialchars($message['message']); ?></p>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-center py-4">No contact messages yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <footer class="pt-3 mt-4 text-muted border-top">
                    &copy; <?php echo date('Y'); ?> Sweet Delights Bakery
                </footer>
            </main>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
