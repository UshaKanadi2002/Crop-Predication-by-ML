<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Clear all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Start new session for message
session_start();
$_SESSION['message'] = 'You have been successfully logged out of the admin panel.';
$_SESSION['message_type'] = 'success';

// Redirect to login page
header('Location: login.php');
exit;
?>