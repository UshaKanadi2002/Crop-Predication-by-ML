-- Sweet Delights Bakery Database Schema for SQLite
-- This script creates the necessary tables for the bakery website

-- Drop tables if they exist (in reverse order of creation to avoid foreign key constraints)
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;

-- Create categories table
CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create products table
CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    price REAL NOT NULL,
    category_id INTEGER NOT NULL,
    featured INTEGER DEFAULT 0,
    allergens TEXT,
    ingredients TEXT,
    image TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Create contact_messages table
CREATE TABLE contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default categories
INSERT INTO categories (name, description) VALUES
('Breads', 'Freshly baked breads made with traditional techniques'),
('Pastries', 'Flaky, buttery pastries for any occasion'),
('Cakes', 'Beautiful and delicious cakes for celebrations'),
('Cookies', 'Sweet treats perfect with coffee or tea'),
('Cupcakes', 'Perfectly portioned individual cakes with various frostings'),
('Pies', 'Sweet and savory pies with flaky crusts');

-- Insert sample products
INSERT INTO products (name, description, price, category_id, featured, allergens, ingredients, image) VALUES
('Sourdough Bread', 'Our signature sourdough bread is made with a decade-old starter that gives it a distinct tangy flavor and chewy texture. Each loaf is hand-shaped and baked to perfection with a crispy crust.', 6.99, 1, 1, 'Contains: Wheat, Gluten', 'Flour, Water, Salt, Sourdough Starter', 'https://images.unsplash.com/photo-1585478259715-4aa543f99cd7?auto=format&fit=crop&w=600&q=80'),

('French Baguette', 'Traditional French baguette with a crisp crust and light, airy interior. Perfect for sandwiches or alongside soups and stews.', 4.99, 1, 0, 'Contains: Wheat, Gluten', 'Flour, Water, Yeast, Salt', 'https://images.unsplash.com/photo-1597079840151-7df4404aee8a?auto=format&fit=crop&w=600&q=80'),

('Chocolate Croissant', 'Buttery, flaky croissant filled with rich dark chocolate. The perfect indulgent breakfast or anytime treat.', 3.99, 2, 1, 'Contains: Wheat, Dairy, Gluten', 'Flour, Butter, Chocolate, Sugar, Yeast', 'https://images.unsplash.com/photo-1549903072-7e6e0bedb7fb?auto=format&fit=crop&w=600&q=80'),

('Classic Vanilla Cake', 'Moist vanilla cake layers filled and frosted with smooth vanilla buttercream. A timeless classic suitable for any celebration.', 32.99, 3, 1, 'Contains: Wheat, Dairy, Eggs', 'Flour, Sugar, Butter, Eggs, Vanilla', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80'),

('Chocolate Chip Cookies', 'Chewy on the inside, crispy on the edges, loaded with premium chocolate chips. Our best-selling cookie!', 2.49, 4, 1, 'Contains: Wheat, Dairy, Eggs', 'Flour, Butter, Sugar, Chocolate Chips, Eggs, Vanilla', 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=600&q=80'),

('Red Velvet Cupcake', 'Velvety smooth red velvet cupcake topped with cream cheese frosting and a light dusting of cake crumbs.', 3.99, 5, 1, 'Contains: Wheat, Dairy, Eggs', 'Flour, Sugar, Cocoa, Buttermilk, Cream Cheese, Butter', 'https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?auto=format&fit=crop&w=600&q=80'),

('Apple Pie', 'Classic apple pie made with tart Granny Smith apples, warm spices, and our signature flaky crust.', 24.99, 6, 0, 'Contains: Wheat, Dairy', 'Flour, Butter, Apples, Sugar, Cinnamon', 'https://images.unsplash.com/photo-1535920527002-b35e96722eb9?auto=format&fit=crop&w=600&q=80'),

('Cinnamon Roll', 'Soft, fluffy cinnamon roll swirled with brown sugar and cinnamon, topped with cream cheese glaze.', 4.49, 2, 1, 'Contains: Wheat, Dairy, Gluten', 'Flour, Butter, Sugar, Cinnamon, Cream Cheese', 'https://images.unsplash.com/photo-1583527976767-a81d95aaf10e?auto=format&fit=crop&w=600&q=80'),

('Whole Wheat Bread', 'Nutritious whole wheat bread made with 100% whole grains. Perfect for sandwiches and toast.', 5.99, 1, 0, 'Contains: Wheat, Gluten', 'Whole Wheat Flour, Water, Honey, Yeast, Salt', 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80'),

('Blueberry Muffin', 'Moist blueberry muffin bursting with fresh blueberries and topped with a sugar crumble.', 3.49, 2, 0, 'Contains: Wheat, Dairy, Eggs', 'Flour, Sugar, Butter, Eggs, Blueberries', 'https://images.unsplash.com/photo-1607958996333-41aef7caefaa?auto=format&fit=crop&w=600&q=80'),

('Chocolate Fudge Cake', 'Decadent chocolate cake with rich fudge frosting. A chocolate lover\'s dream come true.', 36.99, 3, 0, 'Contains: Wheat, Dairy, Eggs', 'Flour, Sugar, Cocoa, Butter, Eggs, Chocolate', 'https://images.unsplash.com/photo-1602351447937-745cb720612f?auto=format&fit=crop&w=600&q=80'),

('Oatmeal Raisin Cookies', 'Chewy oatmeal cookies filled with plump raisins and a hint of cinnamon.', 2.49, 4, 0, 'Contains: Wheat, Dairy, Eggs', 'Flour, Oats, Butter, Sugar, Eggs, Raisins, Cinnamon', 'https://images.unsplash.com/photo-1590080875728-5aa184cbce61?auto=format&fit=crop&w=600&q=80');