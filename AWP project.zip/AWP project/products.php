<?php
$page_title = "Our Products";
require_once 'includes/header.php';

// Get category filter from URL
$category_filter = isset($_GET['category']) ? $_GET['category'] : null;

// Get all categories
$categories = getCategories($conn);

// Get products based on category filter
$products = getProducts($conn, $category_filter);
?>

<!-- Products Header Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h1 class="text-center mb-0">Our Delicious Products</h1>
    </div>
</section>

<!-- Category Filter -->
<section class="container mt-4">
    <div class="d-flex justify-content-center flex-wrap mb-4">
        <a href="products.php" class="btn <?php echo !$category_filter ? 'btn-primary' : 'btn-outline-primary'; ?> m-1 category-filter" data-category="all">All Products</a>
        
        <?php foreach ($categories as $category): ?>
        <a href="products.php?category=<?php echo urlencode($category['name']); ?>" 
            class="btn <?php echo $category_filter === $category['name'] ? 'btn-primary' : 'btn-outline-primary'; ?> m-1 category-filter" 
            data-category="<?php echo $category['name']; ?>">
            <?php echo $category['name']; ?>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- Products Section -->
<section class="container mb-5">
    <div class="row">
        <?php if (count($products) > 0): ?>
            <?php foreach ($products as $product): ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="card product-card h-100">
                    <div class="product-img-container d-flex align-items-center justify-content-center">
                        <?php if ($product['image']): ?>
                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="card-img-top">
                        <?php else: ?>
                        <i class="fas fa-cookie"></i>
                        <?php endif; ?>
                        <?php if ($product['featured']): ?>
                        <span class="badge bg-primary product-badge">Featured</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $product['name']; ?></h5>
                        <p class="card-text text-muted small"><?php echo $product['category_name']; ?></p>
                        <p class="product-price mb-2"><?php echo formatPrice($product['price']); ?></p>
                        <p class="card-text small"><?php echo substr($product['description'], 0, 60) . (strlen($product['description']) > 60 ? '...' : ''); ?></p>
                        <form action="cart.php" method="post">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <div class="d-grid gap-2">
                                <a href="product-detail.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                                <button type="submit" class="btn btn-primary btn-sm add-to-cart-btn">
                                    <i class="fas fa-shopping-cart me-1"></i> Add to Cart
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-cookie-bite fa-4x text-muted mb-3"></i>
                <h3>No products found</h3>
                <?php if ($category_filter): ?>
                <p>No products available in this category. Try a different category or view all products.</p>
                <a href="products.php" class="btn btn-primary mt-3">View All Products</a>
                <?php else: ?>
                <p>We're updating our product catalog. Please check back soon!</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
