<?php
$page_title = "Contact Us";
require_once 'includes/header.php';

$name = $email = $subject = $message = '';
$name_err = $email_err = $message_err = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate name
    if (empty(trim($_POST['name']))) {
        $name_err = 'Please enter your name';
    } else {
        $name = sanitize($_POST['name']);
    }
    
    // Validate email
    if (empty(trim($_POST['email']))) {
        $email_err = 'Please enter your email';
    } else {
        $email = sanitize($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_err = 'Please enter a valid email address';
        }
    }
    
    // Get subject
    $subject = sanitize($_POST['subject'] ?? '');
    
    // Validate message
    if (empty(trim($_POST['message']))) {
        $message_err = 'Please enter your message';
    } else {
        $message = sanitize($_POST['message']);
    }
    
    // If no errors, process the form
    if (empty($name_err) && empty($email_err) && empty($message_err)) {
        // In a real application, you would send the email here
        // For demonstration purposes, we'll just simulate success
        
        // Store message in database
        $sql = "INSERT INTO contact_messages (name, email, subject, message, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $name, $email, $subject, $message);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Your message has been sent. We'll get back to you soon!";
            $_SESSION['message_type'] = "success";
            
            // Reset form fields
            $name = $email = $subject = $message = '';
        } else {
            $_SESSION['message'] = "Oops! Something went wrong. Please try again later.";
            $_SESSION['message_type'] = "danger";
        }
        
        $stmt->close();
        
        // Redirect to avoid form resubmission
        header("Location: contact.php");
        exit;
    }
}
?>

<!-- Contact Hero Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h1 class="mb-3">Contact Us</h1>
                <p class="lead">We'd love to hear from you! Whether you have a question about our products, want to place a special order, or provide feedback, our team is here for you.</p>
            </div>
        </div>
    </div>
</section>

<!-- Contact Information Cards -->
<section class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="contact-info-card">
                <i class="fas fa-map-marker-alt"></i>
                <h4>Our Location</h4>
                <p>123 Bakery Street<br>City, Country</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="contact-info-card">
                <i class="fas fa-phone"></i>
                <h4>Phone Number</h4>
                <p>(123) 456-7890</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="contact-info-card">
                <i class="fas fa-envelope"></i>
                <h4>Email Address</h4>
                <p>info@sweetdelights.com</p>
            </div>
        </div>
    </div>
</section>

<!-- Contact Form Section -->
<section class="container my-5">
    <div class="row">
        <div class="col-lg-6 mb-4 mb-lg-0">
            <h2>Send Us a Message</h2>
            <p>We aim to respond to all inquiries within 24 hours during our business days.</p>
            
            <form id="contact-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="mb-3">
                    <label for="name" class="form-label">Your Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control <?php echo !empty($name_err) ? 'is-invalid' : ''; ?>" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                    <?php if (!empty($name_err)): ?>
                    <div class="invalid-feedback"><?php echo $name_err; ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                    <input type="email" class="form-control <?php echo !empty($email_err) ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                    <?php if (!empty($email_err)): ?>
                    <div class="invalid-feedback"><?php echo $email_err; ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label for="subject" class="form-label">Subject</label>
                    <input type="text" class="form-control" id="subject" name="subject" value="<?php echo htmlspecialchars($subject); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="message" class="form-label">Your Message <span class="text-danger">*</span></label>
                    <textarea class="form-control <?php echo !empty($message_err) ? 'is-invalid' : ''; ?>" id="message" name="message" rows="5" required><?php echo htmlspecialchars($message); ?></textarea>
                    <?php if (!empty($message_err)): ?>
                    <div class="invalid-feedback"><?php echo $message_err; ?></div>
                    <?php endif; ?>
                </div>
                
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
        
        <div class="col-lg-6">
            <h2>Visit Our Bakery</h2>
            <div class="ratio ratio-4x3 mb-4 shadow rounded">
                <div class="bg-secondary-light d-flex align-items-center justify-content-center">
                    <i class="fas fa-map-marked-alt fa-5x text-primary opacity-25"></i>
                    <span class="position-absolute text-center">Map would be displayed here</span>
                </div>
            </div>
            
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5><i class="fas fa-clock text-primary me-2"></i> Business Hours</h5>
                    <ul class="list-unstyled mb-0">
                        <li class="d-flex justify-content-between py-2 border-bottom">
                            <span>Monday - Friday</span>
                            <span>7:00 AM - 7:00 PM</span>
                        </li>
                        <li class="d-flex justify-content-between py-2 border-bottom">
                            <span>Saturday</span>
                            <span>8:00 AM - 5:00 PM</span>
                        </li>
                        <li class="d-flex justify-content-between py-2">
                            <span>Sunday</span>
                            <span>8:00 AM - 3:00 PM</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5">Frequently Asked Questions</h2>
        
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Do you offer delivery?
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, we offer delivery within a 10-mile radius of our bakery for orders over $30. Delivery fees may apply depending on your location. For larger orders or events, we can arrange delivery to suit your needs.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                How far in advance should I order a custom cake?
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                For standard custom cakes, we recommend placing your order at least 48-72 hours in advance. For wedding cakes or elaborate custom designs, we suggest ordering 2-4 weeks ahead to ensure we can accommodate your request and schedule a consultation if needed.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Do you accommodate dietary restrictions?
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We offer a variety of options for different dietary needs, including gluten-free, dairy-free, and vegan items. Our kitchen does process common allergens, so we cannot guarantee against cross-contamination. Please inform us of any severe allergies when placing your order.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Can I freeze your baked goods?
                            </button>
                        </h2>
                        <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Many of our products freeze well. Breads, unfrosted cakes, and cookies can be frozen for up to 3 months if properly wrapped. For best results, let items cool completely before wrapping tightly in plastic wrap and placing in a freezer bag. Thaw at room temperature before serving.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
