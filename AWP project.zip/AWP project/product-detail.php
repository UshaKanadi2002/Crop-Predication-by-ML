<?php
require_once 'includes/header.php';

// Get product ID from URL parameter
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get product details
$product = getProductById($conn, $product_id);

// If product not found, redirect to products page
if (!$product) {
    $_SESSION['message'] = "Product not found.";
    $_SESSION['message_type'] = "warning";
    header("Location: products.php");
    exit;
}

$page_title = $product['name'];

// Get related products
$sql = "SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.category_id = " . $product['category_id'] . " 
        AND p.id != " . $product_id . " 
        ORDER BY RAND() 
        LIMIT 4";
$result = $conn->query($sql);
$related_products = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $related_products[] = $row;
    }
}

// Handle add to cart action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    addToCart($product_id, $quantity);
    
    $_SESSION['message'] = "Product added to cart.";
    $_SESSION['message_type'] = "success";
    
    header("Location: product-detail.php?id=" . $product_id);
    exit;
}
?>

<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="products.php">Products</a></li>
            <li class="breadcrumb-item"><a href="products.php?category=<?php echo urlencode($product['category_name']); ?>"><?php echo $product['category_name']; ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $product['name']; ?></li>
        </ol>
    </nav>
</div>

<!-- Product Detail Section -->
<section class="container mb-5">
    <div class="row">
        <div class="col-md-6">
            <div class="product-img-container d-flex align-items-center justify-content-center bg-white shadow-sm rounded" style="height: 400px;">
                <?php if ($product['image']): ?>
                <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="img-fluid">
                <?php else: ?>
                <i class="fas fa-cookie fa-8x text-primary opacity-25"></i>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <h1 class="mb-3"><?php echo $product['name']; ?></h1>
            
            <p class="text-muted mb-3">
                <span class="badge bg-light text-dark"><?php echo $product['category_name']; ?></span>
                <?php if ($product['featured']): ?>
                <span class="badge bg-primary ms-2">Featured</span>
                <?php endif; ?>
            </p>
            
            <h3 class="text-primary mb-4"><?php echo formatPrice($product['price']); ?></h3>
            
            <div class="mb-4">
                <h5>Description</h5>
                <p><?php echo nl2br($product['description']); ?></p>
            </div>
            
            <form method="post" class="mb-4">
                <div class="row g-3 align-items-center mb-3">
                    <div class="col-auto">
                        <label for="quantity" class="col-form-label">Quantity:</label>
                    </div>
                    <div class="col-auto">
                        <input type="number" id="quantity" name="quantity" class="form-control" value="1" min="1" max="10">
                    </div>
                </div>
                
                <button type="submit" name="add_to_cart" class="btn btn-primary btn-lg">
                    <i class="fas fa-shopping-cart me-2"></i> Add to Cart
                </button>
            </form>
            
            <div class="mb-4">
                <h5>Product Details</h5>
                <ul class="list-unstyled">
                    <li><strong>Allergens:</strong> 
                        <?php 
                            echo !empty($product['allergens']) ? $product['allergens'] : 'Information not available';
                        ?>
                    </li>
                    <li><strong>Ingredients:</strong> 
                        <?php 
                            echo !empty($product['ingredients']) ? $product['ingredients'] : 'Information not available';
                        ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Related Products Section -->
<?php if (count($related_products) > 0): ?>
<section class="container mb-5">
    <h3 class="mb-4">You May Also Like</h3>
    <div class="row">
        <?php foreach ($related_products as $related): ?>
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card product-card h-100">
                <div class="product-img-container d-flex align-items-center justify-content-center">
                    <?php if ($related['image']): ?>
                    <img src="<?php echo $related['image']; ?>" alt="<?php echo $related['name']; ?>" class="card-img-top">
                    <?php else: ?>
                    <i class="fas fa-cookie"></i>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $related['name']; ?></h5>
                    <p class="product-price mb-2"><?php echo formatPrice($related['price']); ?></p>
                    <div class="d-grid gap-2">
                        <a href="product-detail.php?id=<?php echo $related['id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                        <form action="cart.php" method="post">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="product_id" value="<?php echo $related['id']; ?>">
                            <button type="submit" class="btn btn-primary btn-sm w-100 add-to-cart-btn">
                                <i class="fas fa-shopping-cart me-1"></i> Add to Cart
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
