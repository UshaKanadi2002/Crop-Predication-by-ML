<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Get all products from the database
 * 
 * @param PDO $conn Database connection
 * @param string|null $category Optional category filter
 * @return array Array of products
 */
function getProducts($conn, $category = null) {
    $products = [];
    
    $sql = "SELECT p.*, c.name as category_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id";
    
    $params = [];
    
    if ($category) {
        $sql .= " WHERE c.name = :category";
        $params[':category'] = $category;
    }
    
    $sql .= " ORDER BY p.id DESC";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Log error
        error_log("Database error: " . $e->getMessage());
    }
    
    return $products;
}

/**
 * Get a single product by ID
 * 
 * @param PDO $conn Database connection
 * @param int $id Product ID
 * @return array|null Product data or null if not found
 */
function getProductById($conn, $id) {
    $id = (int)$id;
    
    $sql = "SELECT p.*, c.name as category_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            WHERE p.id = :id";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        // Log error
        error_log("Database error: " . $e->getMessage());
    }
    
    return null;
}

/**
 * Get all categories from the database
 * 
 * @param PDO $conn Database connection
 * @return array Array of categories
 */
function getCategories($conn) {
    $categories = [];
    
    $sql = "SELECT * FROM categories ORDER BY name";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Log error
        error_log("Database error: " . $e->getMessage());
    }
    
    return $categories;
}

/**
 * Format price to display with currency symbol
 * 
 * @param float $price Price to format
 * @return string Formatted price
 */
function formatPrice($price) {
    return '$' . number_format($price, 2);
}

/**
 * Add product to shopping cart
 * 
 * @param int $productId Product ID
 * @param int $quantity Quantity to add
 */
function addToCart($productId, $quantity = 1) {
    $productId = (int)$productId;
    $quantity = (int)$quantity;
    
    if ($quantity <= 0) {
        $quantity = 1;
    }
    
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] += $quantity;
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }
}

/**
 * Update cart item quantity
 * 
 * @param int $productId Product ID
 * @param int $quantity New quantity
 */
function updateCartItem($productId, $quantity) {
    $productId = (int)$productId;
    $quantity = (int)$quantity;
    
    if ($quantity <= 0) {
        removeCartItem($productId);
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }
}

/**
 * Remove item from cart
 * 
 * @param int $productId Product ID to remove
 */
function removeCartItem($productId) {
    $productId = (int)$productId;
    
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
    }
}

/**
 * Get cart items with product details
 * 
 * @param PDO $conn Database connection
 * @return array Cart items with product details
 */
function getCartItems($conn) {
    $items = [];
    $total = 0;
    
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $productId => $quantity) {
            $product = getProductById($conn, $productId);
            
            if ($product) {
                $subtotal = $product['price'] * $quantity;
                $total += $subtotal;
                
                $items[] = [
                    'id' => $productId,
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'quantity' => $quantity,
                    'subtotal' => $subtotal,
                    'image' => $product['image']
                ];
            }
        }
    }
    
    return [
        'items' => $items,
        'total' => $total
    ];
}

/**
 * Count items in cart
 * 
 * @return int Number of items in cart
 */
function getCartItemCount() {
    $count = 0;
    
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $quantity) {
            $count += $quantity;
        }
    }
    
    return $count;
}

/**
 * Check if user is logged in
 * 
 * @return bool True if user is logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user is logged in as admin
 * 
 * @return bool True if user is admin, false otherwise
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Check if user is a customer (logged in but not admin)
 * 
 * @return bool True if user is a customer, false otherwise
 */
function isCustomer() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'customer';
}

/**
 * Get current user's ID
 * 
 * @return int|null User ID if logged in, null otherwise
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get user by ID
 * 
 * @param PDO $conn Database connection
 * @param int $id User ID
 * @return array|null User data or null if not found
 */
function getUserById($conn, $id) {
    $id = (int)$id;
    
    $sql = "SELECT * FROM users WHERE id = :id";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        // Log error
        error_log("Database error: " . $e->getMessage());
    }
    
    return null;
}

/**
 * Sanitize input data
 * 
 * @param string $data Data to sanitize
 * @return string Sanitized data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Generate a random string
 * 
 * @param int $length Length of the string
 * @return string Random string
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $randomString;
}

/**
 * Display alert message
 * 
 * @param string $message Message to display
 * @param string $type Alert type (success, danger, warning, info)
 * @return string HTML for alert message
 */
function showAlert($message, $type = 'info') {
    return '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">
                ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
}
?>
