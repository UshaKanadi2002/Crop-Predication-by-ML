<?php
// Database settings
$db_file = __DIR__ . '/../database/bakery.db';

// Create SQLite database if it doesn't exist
if (!file_exists($db_file)) {
    // Run the database initialization script
    include_once __DIR__ . '/../database/init_db.php';
}

// Global PDO variable
global $pdo;

// Create PDO database connection
try {
    $pdo = new PDO('sqlite:' . $db_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Modified functions.php to work with PDO instead of mysqli
    $conn = $pdo; // This will be used as a reference to the PDO object
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
