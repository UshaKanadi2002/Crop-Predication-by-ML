<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Clear all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Set a message
session_start();
$_SESSION['message'] = 'You have been successfully logged out.';
$_SESSION['message_type'] = 'success';

// Redirect to home page
header('Location: index.php');
exit;
?>